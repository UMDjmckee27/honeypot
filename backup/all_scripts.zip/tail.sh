#!/bin/bash
# Description: Monitors the honeypot log for attacker connection, enforces firewall rules,
#              tracks connection time and activity, and recycles the container on disconnect or timeout.
# Usage: ./monitor_attack.sh <EXTERNAL_IP> <MITM_PORT> <CONTAINER_NAME>

# Define script arguments
EXTERN_IP=$1
MITM_PORT=$2
CONTAINER=$3

# --- Configuration Variables ---

# Placeholder for the internal LXC/container bridge IP address (e.g., 10.0.3.1)
# Update this if your internal network configuration is different.
INTERNAL_IP_PLACEHOLDER="10.0.3.1"

# Log patterns for connection monitoring
OPEN_PATTERN="\[Connection\] Attacker connected"
CLOSE_PATTERN="closed connection|closed the connection"

# Log and flag file paths (Paths assume the /home/student/ structure of the operating environment)
LOG_FOLDER=$(echo "$CONTAINER" | cut -d'_' -f1-3 )
LOG_FILE="/home/student/mitm_logs/$LOG_FOLDER/$CONTAINER.log"
FLAG_FILE="/home/student/$MITM_PORT"
HUNNYPOT_LOG_PATH="/home/student/hunnypot_logs/$MITM_PORT.log"

# Timeouts in seconds
CHECK_INTERVAL=1
IDLE_LIMIT=300
MAX_CONNECTION_TIME=1800

# Create the flag file to signal the monitoring loop
touch "$FLAG_FILE"

# --- Phase 1: Wait for Attacker Connection ---

echo "$(date +"%Y-%m-%d %H:%M:%S"): Waiting for attacker" >> "$HUNNYPOT_LOG_PATH"
# Tail the log file and wait for the open pattern.
tail -F "$LOG_FILE" | while read -r LINE; do
    if echo "$LINE" | grep -q "$OPEN_PATTERN"; then
        # Extract the attacker IP (assuming it's the 8th field in the log line)
        echo "$LINE" | awk '{print $8}' > "$FLAG_FILE"
        break
    fi
done

ATTACKER_IP=$(cat "$FLAG_FILE")

# --- Phase 2: Apply Firewall Rules to Isolate Attacker ---

# Block all incoming traffic to the internal MITM IP on this port
sudo iptables -I INPUT -d "$INTERNAL_IP_PLACEHOLDER" -p tcp --dport "$MITM_PORT" -j DROP
# ONLY allow traffic from the identified attacker IP to the internal MITM IP on this port
sudo iptables -I INPUT -s "$ATTACKER_IP" -d "$INTERNAL_IP_PLACEHOLDER" -p tcp --dport "$MITM_PORT" -j ACCEPT

# Record connection start time in the flag file (UNIX epoch time)
echo $(date +%s) > "$FLAG_FILE"
connection_start=$(cat "$FLAG_FILE")

# --- Phase 3: Monitor Connection Activity and Timeouts ---

echo "$(date +"%Y-%m-%d %H:%M:%S"): Attacker connected, monitoring log file ($ATTACKER_IP)" >> "$HUNNYPOT_LOG_PATH"
while [ -f "$FLAG_FILE" ] ; do
    # Use 'timeout' on 'tail -F' to check for activity only for CHECK_INTERVAL
    timeout --foreground "$CHECK_INTERVAL" tail -n 0 -F "$LOG_FILE" | while read -r LINE; do
        # If any log line comes through (activity detected), update the last active time
        echo $(date +%s) > "$FLAG_FILE"

        if echo "$LINE" | grep -q -E "$CLOSE_PATTERN"; then
            echo "$(date +"%Y-%m-%d %H:%M:%S"): Attacker exited" >> "$HUNNYPOT_LOG_PATH"
            rm -f "$FLAG_FILE"
            break
        fi
    done

    # Recalculate times
    current_time=$(date +%s)
    last_active=$(cat "$FLAG_FILE") 
    idle_time=$((current_time - last_active))
    connection_time=$((current_time - connection_start))

    # Check for idle timeout
    if (( idle_time >= IDLE_LIMIT )); then
        echo "$(date +"%Y-%m-%d %H:%M:%S"): Attacker reached idle time ($IDLE_LIMIT seconds)" >> "$HUNNYPOT_LOG_PATH"
        rm -f "$FLAG_FILE"
        break
    fi

    # Check for maximum connection time
    if (( connection_time >= MAX_CONNECTION_TIME )); then
        echo "$(date +"%Y-%m-%d %H:%M:%S"): Attacker reached max time ($MAX_CONNECTION_TIME seconds)" >> "$HUNNYPOT_LOG_PATH"
        rm -f "$FLAG_FILE"
        break
    fi
done

# --- Phase 4: Cleanup and Recycle ---

# Remove firewall rules
sudo iptables -D INPUT -d "$INTERNAL_IP_PLACEHOLDER" -p tcp --dport "$MITM_PORT" -j DROP
sudo iptables -D INPUT -s "$ATTACKER_IP" -d "$INTERNAL_IP_PLACEHOLDER" -p tcp --dport "$MITM_PORT" -j ACCEPT

echo "$(date +"%Y-%m-%d %H:%M:%S"): Running recycle script to reset honeypot" >> "$HUNNYPOT_LOG_PATH"
# Call the recycle script to destroy and recreate the container
sudo /home/student/recycle.sh "$EXTERN_IP" "$MITM_PORT" "$CONTAINER"&
